#ifndef flash_h
#define flash_h

struct wConf { char ssid[32]; char passwd[32]; };

void save_wifiApConf(char*,int*);		// "ssid,passwd"
void read_wifiApConf(struct wConf *wifiApConf);

#endif /*flash_h*/
