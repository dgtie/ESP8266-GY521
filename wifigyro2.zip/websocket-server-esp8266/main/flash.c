/* http://marrin.org/2017/01/16/putting-data-in-esp8266-flash-memory/ */
/* https://www.esp8266.com/viewtopic.php?f=34&t=2662 */
/* https://www.esp8266.com/viewtopic.php?p=69186 */
/* sector 0x8c is free */

#include "spi_flash.h"
#include "os.h"
#include "flash.h"

void save_wifiApConf(char *string, int *len) {
  struct wConf wifiApConf;
  int i = sizeof(struct wConf);
  while (i) wifiApConf.ssid[--i] = 0xff;
  for (i = *len-1; i>=0 ; --i) if (string[i] == ',') break;
  if (i < 0) return;
  string[i] = 0;
  os_memcpy(wifiApConf.ssid, string, ++i);
  *len -= i;
  os_memcpy(wifiApConf.passwd, &string[i], *len);
  wifiApConf.passwd[*len] = 0;
  spi_flash_erase_sector(0x8c);
  spi_flash_write(0x8c000, &wifiApConf, sizeof(struct wConf));
}

void read_wifiApConf(struct wConf *wifiApConf) {
  spi_flash_read(0x8c000, wifiApConf, sizeof(struct wConf));
}
