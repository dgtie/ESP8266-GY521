/*
#include <stdio.h>

void websocket_init();
char *websocket(char *b, int *len);

char string1[] = 
"GET / HTTP/1.1\r\n"
"Host: 192.168.50.236:3333\r\n"
"Connection: Upgrade\r\n"
"Pragma: no-cache\r\n"
"Cache-Control: no-cache\r\n"
"User-Agent: Mozilla/";

char string2[] = 
"5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36\r\n"
"Upgrade: websocket\r\n"
"Origin:"; 

char string3[] = 
"file://\r\n"
"Sec-WebSocket-Version: 13\r\n"
"Accept-Encoding: gzip, deflate\r\n"
"Accept-Language: en-GB,en-US;q=0.9,en;q=0.8\r\n"
"Sec-WebSocket-";

char string4[] = 
"Key: PFiYMqZQZkDWyogNwtWRNQ==\r\n"
"Sec-WebSocket-Extensions: permessage-deflate; client_max_window_bits\r\n\r\n";

char string5[] = "hi hi\r\n";

int main() {
  char *ptr;
  websocket_init();
  int len;
  len = sizeof(string1)-1;
  ptr = websocket(string1, &len);
  if (ptr) printf("string1: %s\n", ptr);
  len = sizeof(string2)-1;
  ptr = websocket(string2, &len);
  if (ptr) printf("string2: %s\n", ptr);
  len = sizeof(string3)-1;
  ptr = websocket(string3, &len);
  if (ptr) printf("string3: %s\n", ptr);
  len = sizeof(string4)-1;
  ptr = websocket(string4, &len);
  if (ptr) { ptr[len] = 0; printf("string4: %s\n", ptr); }
  len = sizeof(string5)-1;
  ptr = websocket(string5, &len);
  if (ptr) { ptr[len] = 0; printf("string5: %s\n", ptr); }
}
//*//////////////////////////////////////////////////////////////////

void search(const char *p);
int found(void);	// 0 = found; -1 = not found
const char *scan(char c);
int encrypt(char*, char*);

char *get_mpu_data(char*, int *len);	// *len = -1 when data not ready
char *save_wifi_info(char*, int *len);

static char *ptr;

static char response[] =
"HTTP/1.1 101 Switching Protocols\r\n"
"Upgrade: websocket\r\n"
"Connection: Upgrade\r\n"
"Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=\r\n\r\n";
//"Sec-WebSocket-Protocol: chat\r\n\r\n";
//97 = s3pPL...

static int connected;

void websocket_init() {
  search("Sec-WebSocket-Key: ");
  connected = 0;
}

static void handshake(char *b, int len) {
  int i = 0;
  if (found() == -1) {
    for (i = 0; i < len; i++)
      if (!scan(b[i])) {
        if (b[i] == '\n') { connected = 1; return; }
        i++; ptr = &response[97]; break;
      }
  }
  if (found() == 0) {
    while (i < len) {
      *ptr = b[i++];
      if (*ptr == '\r') {
        *ptr = 0;
        encrypt(&response[97], &response[97]);
        search("\r\n\r\n");
        scan('\r');
        while (i < len)
          if (!scan(b[i++])) { connected = 1; return; }
      } else ptr++;
    }
  }
}

static char *unmask(char *p) {
  int mask = 0, len = p[1] & 127;
  char *q;
  if (*p != (char)0x81) return 0;
  if (p[1] & 0x80) {
    q = &p[6];
    p = &p[2];
    for (int i = 0; i < len; i++) {
      q[i] ^= p[mask++];
      mask &= 3;
    }
  } else {
    q = &p[2];
    q[len] = 0;
  }
  return q;
}

// input: *len==-1 to get mpu data
//        *len!=-1 to process data in 'b'
// output: *len==0 to request disconnection
//         *len==-1 to indicate mpu data not ready
//         otherwise return data to send
//         return null to skip send
char *websocket(char *b, int *len) {
  if (*len == -1) return get_mpu_data(0, len);
  if (connected) {
    unmask(b);
    b[4] = b[0];		// prepare to echo
    *len = b[5] = b[1] & 127;	// data @ b[4]
    if (b[5] == 0) return 0;	// null input to disconnect
    if (b[6] == '\n') return get_mpu_data(&b[7], len);
    *len -= 1;
    if (b[6] == '\a') return save_wifi_info(&b[7], len);
    *len += 3;
    return &b[4];
  } else {
    handshake(b, *len);
    *len = sizeof(response) - 1;
    return connected ? response : 0;
  }
}
//////////////////////////////////////////////////////////////////////////
#include "flash.h"

static char mpu_data[115] = { 0x82, 113 };
static char buffer[113], sn;
static int index, expected_sn;
static int ready_to_send = 0;

static int _buffer_full() { return index > 7 ? 1 : 0; }

void save_mpu_data(char *d) {	// check buffer_full() before calling
  for (int i = 0; i < 14; i++) buffer[index*14+i+1] = d[i];
  if (index++ == 0) buffer[0] = sn;
}

static int char2int(unsigned char c) {
  int i = c - '0';
  if (i < 0) return 16;
  if (i < 10) return i;
  i = c - 'a';
  if (i < 0) return 16;
  return i < 6 ? i + 10 : 16;
}
static int str2int(char *s) {
  int i = 0, j = 0, k;
  while (s[i]) {
    k = char2int((unsigned char)s[i++]);
    if (k > 15) break;
    j = j * 16 + k;
  }
  return j;
}
char *get_mpu_data(char *s, int *len) {
  if (s) {
    s[*len] = 0;
    expected_sn = str2int(s);
    if (expected_sn == 256) index = ready_to_send = 0;
  }
  if (ready_to_send) { *len = 115; ready_to_send = 0; }
  else *len = -1;
  return mpu_data;
}

char *save_wifi_info(char *b, int *len) {
  int i = 0;
  struct wConf wifi;
  read_wifiApConf(&wifi);
  save_wifiApConf(b, len);
  if (wifi.ssid[0] == 0xff) wifi.ssid[0] = wifi.passwd[0] = 0;
  while (wifi.ssid[i]) { b[i+2] = wifi.ssid[i]; i++; }
  b[0] = 0x81; b[1] = i & 127; *len = i + 2;
  return b;
}

int buffer_full() {
  sn++;
  if (!_buffer_full()) return 0;
  if (ready_to_send) return 1;
  for (int i = 0; i < 113; i++) mpu_data[i+2] = buffer[i];
  ready_to_send = 1;
  return index = 0;
}
